const allProducts = [
    {id:1, price:120_000 , img:'./../public/pizza/pizza-1.jpg',name:'Special pepperoni pizza' , info:'Special pepperoni pizza is here to test and like it for ever' , category:'offer'},
    {id:2, price:200_000 , img:'./../public/pizza/pizza-1.png',name:'Custom pepperoni pizza vip' , info:'Custom pepperoni pizza vip is here to test and like it for ever' , category:'Custom'},
    {id:3, price:140_000 , img:'./../public/pizza/pizza-2.jpg',name:'Special pepperoni pizza' , info:'Special pepperoni pizza is here to test and like it for ever' , category:'offer'},
    {id:4, price:210_000 , img:'./../public/pizza/pizza-2.png',name:'Custom pepperoni pizza vip' , info:'Custom pepperoni pizza vip is here to test and like it for ever' , category:'Custom'},
    {id:5, price:230_000 , img:'./../public/pizza/pizza-3.jpg',name:'Special pepperoni pizza' , info:'Special pepperoni pizza is here to test and like it for ever' , category:'offer'},
    {id:6, price:420_000 , img:'./../public/pizza/pizza-3.png',name:'Custom pepperoni pizza vip' , info:'Custom pepperoni pizza vip is here to test and like it for ever' , category:'Custom'},
    {id:7, price:250_000 , img:'./../public/pizza/pizza-1.png',name:'newest pizza with spageti' , info:'newest pizza with spageti is here to test and like it for ever' , category:'newest'},
    {id:8, price:110_000 , img:'./../public/pizza/pizza-4.png',name:'Special pepperoni pizza' , info:'Special pepperoni pizza is here to test and like it for ever' , category:'offer'},
    {id:9, price:150_000 , img:'./../public/pizza/pizza-1.jpg',name:'newest pizza with spageti' , info:'newest pizza with spageti is here to test and like it for ever' , category:'newest'},
    {id:10, price:190_000 , img:'./../public/pizza/pizza-2.jpg',name:'newest pizza with spageti' , info:'newest pizza with spageti is here to test and like it for ever' , category:'newest'},
]

export {allProducts}