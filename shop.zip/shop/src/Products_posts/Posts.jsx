const Posts = [
    {id: 1 ,litleInfo:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam, fugiat?' , img:'./public/blog/main-blog1.png' , title:'The best Asian foods' , moreInfos: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam est quae temporibus asperiores illo debitis natus cum, soluta, harum iusto sunt numquam amet repellendus eius repudiandae quasi veniam cupiditate eaque?'},
    {id: 2 ,litleInfo:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam, fugiat?' , img:'./public/blog/main-blog2.png' , title:'The best European foods' , moreInfos: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam est quae temporibus asperiores illo debitis natus cum, soluta, harum iusto sunt numquam amet repellendus eius repudiandae quasi veniam cupiditate eaque?'},  
    {id: 3 ,litleInfo:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam, fugiat?' , img:'./public/blog/main-blog3.png' , title:'The best American foods' , moreInfos: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam est quae temporibus asperiores illo debitis natus cum, soluta, harum iusto sunt numquam amet repellendus eius repudiandae quasi veniam cupiditate eaque?'},
]


export { Posts }