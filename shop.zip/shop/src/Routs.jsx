import Home from "./component/home/home"
import Shop from "./component/shop/shop"
import Blog from "./component/blog/blog"
import Single from "./component/single/single"
import SingleProduct from "./component/singleProduct/singleProduct"
import Menu from "./component/menu/menu"



const Routs = [
    { path: '/', element: <Home />,},
    { path: '/shop', element: <Shop /> },
    { path: '/blog', element: <Blog /> },
    { path: '/single', element: <Single /> },
    { path: '/singleProduct', element: <SingleProduct /> },
    { path: '/menu/:id', element: <Menu /> },
]


export default Routs