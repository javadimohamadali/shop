import React from 'react'

export default function singleProduct() {
  return (
    <div>singleProduct</div>
  )
}
