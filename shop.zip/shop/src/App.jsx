import './App.css'
import Routs from './Routs'
import { useRoutes } from "react-router"
import 'bootstrap/dist/css/bootstrap.css'
import Footer from './component/footer/footer'

function App() {

  let router = useRoutes(Routs)

  return (
    <>
      {router}
      <Footer />
    </>
  )
}

export default App
