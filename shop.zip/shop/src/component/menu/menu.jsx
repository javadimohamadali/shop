import './menu.css'
import { Row, Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'



export default function menu() {
  return (
    <div className="menu-parent">
      <div className="menu">
        <div className="section-1">
          <Row>
            <Col md={6} className='no-padding'>
              <h1 className='fs-4'>the bests fast foots you ever saw</h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab commodi eligendi nemo architecto odit voluptas perferendis dolores, nostrum aspernatur quaerat ea, labore quae porro, aperiam eveniet quibusdam non distinctio enim.</p>
            </Col>
            <Col md={6} className='no-padding'>
                  <div className="span-menu-berger-haneler">
                  <span>
                    <Link to='/'>berger</Link>
                  </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                <span>
                  <Link to='/'>berger</Link>
                </span>
                  </div>
            </Col>
          </Row>
        </div>
      </div>
    </div>
  )
}
