import './singleProduct.css'

export default function singleProduct() {
  return (
    <div>singleProduct</div>
  )
}
