import React from 'react'
import { Container, Col, Row, Navbar, Nav } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import { Posts } from '../../Products_posts/Posts'
import Posting from '../home/Posting'

export default function single() {
  return (
    <>
      <header>
        <div className="top-wraper page-wraper">

          <Container>
            <Row>
              <Col md={12}>
                <Navbar className="navbar navbar-default z-index-1000">
                  <Container fluid>
                    <Navbar.Collapse id="navbarScroll" className='headerNavHand'>
                      <Nav className="me-auto my-2 my-lg-0 text-white">
                        <NavLink to="/" className='text-white p-2'>Home</NavLink>
                        <NavLink to="/menu/1" className='text-white p-2'>menu</NavLink>
                      </Nav>
                      <NavLink href="/" className='navbar-brand'>
                        <img src="../public/logo.png" alt="" />
                      </NavLink>
                    </Navbar.Collapse>
                  </Container>
                </Navbar>
              </Col>
            </Row>




            <Row className='col'>
              <div className="open mt-5">
                <span>7 days a week</span>
                <p>12 to 12</p>
              </div>
            </Row>




            <Row>
              <div className="top-pic-categorym text-center row">
                <Col xs={2}>
                  <NavLink to="single" target="_blank">
                    <img src="../public/svg/pizzas-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/salads-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/sushi-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/burgers-big.svg" alt="" />
                  </NavLink>
                </Col>

                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/desserts-big.svg" alt="" />
                  </NavLink>
                </Col>

                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/drinks-big.svg" alt="" />
                  </NavLink>
                </Col>
              </div>
            </Row>



            <Row>
              <Col md={12}>

                <ol className="breadcrumb">
                  <li><NavLink to="/">home / </NavLink></li>
                  <li className="active">blog</li>
                </ol>


              </Col>
            </Row>
          </Container>
        </div>
      </header>
      <section>
        <Container>
          <div className="single-post-body">
            <Row>
              <Col sm={8}>
                <img src="./public/blog/main-blog3.png" alt="" className="img-thumbnail" />
                <div className="post-cats">
                  <h4>The best Asian foods</h4>
                  <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur dicta tempore doloribus non voluptatum. Totam libero praesentium minima nihil commodi mollitia, adipisci temporibus saepe quisquam accusamus quidem magni qui quia?</p>
                  <h3>the best foods with salsal </h3>
                  <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquam dolores veniam unde doloremque quibusdam dignissimos optio. Similique veniam unde quos, enim ipsam ad sapiente recusandae dolores, excepturi obcaecati a ipsa?</p>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique ratione maiores sed optio repudiandae eius, dolores esse non nulla, saepe quisquam reiciendis tempora incidunt ab. Tempore cum consequuntur dolores cupiditate aut maxime blanditiis vero reprehenderit iure. Tempore earum ipsam numquam consequatur commodi ad minima amet, dicta sit repudiandae atque non odio expedita dignissimos delectus, alias quas natus soluta! Repellat illum reiciendis minima dolores assumenda ratione non nemo quaerat. Sapiente harum, rerum consequatur labore aspernatur provident repudiandae excepturi obcaecati, facilis rem consequuntur aperiam maxime facere earum dolor voluptas accusantium voluptates et ea atque at incidunt. Dignissimos explicabo blanditiis laudantium illum illo accusamus animi expedita! Iste aliquid rem totam odio neque voluptates, corrupti, maiores quo modi facere tenetur odit obcaecati dicta rerum.</p>
                </div>
                <hr />
                <div className="post-tags">
                  #
                  <a href="#">love</a>
                  <a href="#">siple</a>
                  <a href="#">fight</a>
                </div>
                <hr />
                <div className="releated-posts">
                  <h5 className="text-center">perhaps like</h5>
                </div>
                <Row className='mb-3'>
                  <Posting Posts={Posts} />
                </Row>
                {/* <div className="post-comments">
                  <h5> your comment<i className="fa fa-comments-o"></i></h5>
                  <form className="ctrl">
                    <input type="text" placeholder="your name ..." className="form-control" />
                    <input type="email" placeholder="email" className="form-control" />
                    <textarea className="form-control" cols="30" rows="8" placeholder="your coment about this products"></textarea>
                    <button className="btn">send</button>
                  </form>
                </div> */}
              </Col>
              <Col sm={4}>
                <div className="single-sidebar">
                  <ul className="list-group right">
                    <li className="list-group-item list-group-item-danger v">
                    Your kitchen
                      <span className="badge">14</span>
                    </li>
                    <li className="list-group-item v">
                    Educational 
                      <span className="badge">14</span>
                    </li>
                    <li className="list-group-item v">
                    health knowledge
                    <span className="badge">14</span>
                    </li>
                    <li className="list-group-item v">
                    weblog
                      <span className="badge">14</span>
                    </li>
                    <li className="list-group-item v">
                    Nutrition
                      <span className="badge">14</span>
                    </li>
                  </ul>
                  <ul className="list-group">
                    <li className="list-group-item list-group-item-danger">Latest News </li>
                    <li className="list-group-item">
                      <h4>Special pizza training</h4>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aut, culpa alias. Exercitationem eius molestias iure harum itaque animi .</p>
                    </li>
                    <li className="list-group-item">
                      <h4>why dont eat the best ? </h4>
                      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusantium eaque voluptates enim molestias! Laudantium animi nam .</p>
                    </li>
                    <li className="list-group-item">
                      <h4>why dont were the best ?</h4>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita ab magni architecto quaerat veniam iste dolore harum dolorum ex est quibusdam .</p>
                    </li>
                  </ul>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
    </>
  )
}
