import React from 'react'
import { Container, Row, Col, Nav, Navbar } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import Posting from '../home/Posting'
import { useState, useEffect } from 'react'
import { Posts } from '../../Products_posts/Posts'


export default function blog() {



  let pageSize = 4
  let [pageItemsIndexs, setPageItemsIndexs] = useState(0)
  const [pendding, setPendding] = useState(false)
  const [Products, setProducts] = useState([])
  let pageShow = Products.slice(pageItemsIndexs * pageSize, (pageItemsIndexs + 1) * pageSize)
  let pageLenth = Math.ceil(Products.length / pageSize)
  let pagecount = Array.from(Array(pageLenth).keys())


  useEffect(() => {
    setProducts(Posts)
    setPendding(true)
  }, [])

  return (
    <>
      {
        pendding ? (
          <>
          <header>
            <div className="top-wraper page-wraper">

              <Container>
                <Row>
                  <Col md={12}>
                    <Navbar className="navbar navbar-default z-index-1000">
                      <Container fluid>
                        <Navbar.Collapse id="navbarScroll" className='headerNavHand'>
                          <Nav className="me-auto my-2 my-lg-0 text-white">
                            <NavLink to="/" className='text-white p-2'>Home</NavLink>
                            <NavLink to="/menu/1" className='text-white p-2'>menu</NavLink>
                          </Nav>
                          <NavLink href="/" className='navbar-brand'>
                            <img src="../public/logo.png" alt="" />
                          </NavLink>
                        </Navbar.Collapse>
                      </Container>
                    </Navbar>
                  </Col>
                </Row>




                <Row className='col'>
              <div className="open mt-5">
                <span>7 days a week</span>
                <p>12 to 12</p>
              </div>
            </Row>




                <Row>
                  <div className="top-pic-categorym text-center row">
                    <Col xs={2}>
                      <NavLink to="single" target="_blank">
                        <img src="../public/svg/pizzas-big.svg" alt="" />
                      </NavLink>
                    </Col>
                    <Col xs={2}>
                      <NavLink to="single">
                        <img src="./public/svg/salads-big.svg" alt="" />
                      </NavLink>
                    </Col>
                    <Col xs={2}>
                      <NavLink to="single">
                        <img src="./public/svg/sushi-big.svg" alt="" />
                      </NavLink>
                    </Col>
                    <Col xs={2}>
                      <NavLink to="single">
                        <img src="./public/svg/burgers-big.svg" alt="" />
                      </NavLink>
                    </Col>

                    <Col xs={2}>
                      <NavLink to="single">
                        <img src="./public/svg/desserts-big.svg" alt="" />
                      </NavLink>
                    </Col>

                    <Col xs={2}>
                      <NavLink to="single">
                        <img src="./public/svg/drinks-big.svg" alt="" />
                      </NavLink>
                    </Col>
                  </div>
                </Row>



                <Row>
                  <Col md={12}>

                    <ol className="breadcrumb">
                      <li><NavLink to="/">home / </NavLink></li>
                      <li className="active">blog</li>
                    </ol>


                  </Col>
                </Row>
              </Container>
            </div>
          </header>
            <section>
              <Container>
                <div className="shop-body">
                  <Row className='justify-content-center'>
                    <div className="title-head mt-3">
                      <span>Experience the most delicious taste with us</span>
                    </div>
                    <Posting Posts={pageShow} />
                    <nav aria-label="Page navigation example">
                      <ul className="pagination text-center d-flex justify-content-center">
                        {
                          pagecount.map(page => (
                            <li onClick={(e) => {
                              setPageItemsIndexs(Number(page))
                              e.preventDefault()
                            }} className={`page-item ${pageItemsIndexs === page ? 'active' : ''}`} key={page + 1}><a className="page" href="#">{page + 1}</a></li>
                          ))
                        }
                      </ul>
                    </nav>
                  </Row>
                </div>
              </Container>
            </section>
          </>
        ) : (
          <h1>pendding ... </h1>
        )
      }

    </>
  )
}
