import { Col } from "react-bootstrap"
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';

export default function categoryPaginationProducts({productsUseing}) {

    console.log(productsUseing)

    return (
        <>
            {
                productsUseing.map(Product => (
                    <Col xs={12} md={3} key={Product.id}>
                        <div className="product_bx">
                            <figure>
                                <img src={Product.img} alt="" />
                            </figure>
                            <h5 className="text-center mb-3 mt-3">{Product.name}</h5>
                            <p className="mb-3">{Product.info}</p>
                            <table className="mb-3">
                                <tbody>
                                    <tr>
                                        <td>little </td>
                                        <td>midle</td>
                                        <td>big</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table className="mb-3">
                                <tbody>
                                    <tr>
                                        <td>16 </td>
                                        <td>26</td>
                                        <td>36</td>
                                    </tr>
                                </tbody>
                            </table>
                            <span className="mb-3 price">
                                {Product.price} $
                            </span>
                            <a href="#" className="product_bx_order_BTN"> <AddShoppingCartIcon className="Icon" />  order </a>
                        </div>
                    </Col>
                ))
            }

        </>

    )
}
