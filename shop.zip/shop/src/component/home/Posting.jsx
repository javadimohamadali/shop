import { Col } from "react-bootstrap"
import { Link } from "react-router-dom"
export default function Posting(props) {

    return (
        props.Posts.map(post => (
            <Col md={4} key={post.id}>
                <div className="blog-bx rounded">
                    <a href="#">
                        <img src={post.img} alt="" className='rounded' />
                    </a>
                    <h4>{post.title}</h4>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam, fugiat?</p>
                    <Link to="/blog" className="read position-relative">read more</Link>
                </div>
            </Col>
        ))
    )
}
