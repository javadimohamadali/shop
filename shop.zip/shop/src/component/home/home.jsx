import { Container, Row, Col, Nav, Navbar } from 'react-bootstrap'
import { NavLink } from 'react-router-dom';
import { allProducts } from '../../Products_posts/Products';
import { Posts } from '../../Products_posts/Posts';
import { useEffect, useState } from 'react';
import CategoryPagintion from './CategoryPagintion';
import CategoryPaginationProducts from './categoryPaginationProducts';
import AlternateEmailIcon from '@mui/icons-material/AlternateEmail';
import Posting from './Posting';

export default function home() {

  let allCategory = [...new Set(allProducts.map(product => product.category))]
  const [productsUseing, setProductsUseing] = useState(allProducts.filter(product => product.category === 'offer'))
  const [allCategoryUseing, setAllCategoryUseing] = useState(allCategory)


  const funcCategory = async (categoryFlag) => {
    let newproductsUseing = allProducts.filter(product => product.category === categoryFlag)
    setProductsUseing(newproductsUseing)
  }



  return (


    <>
      <header className='Header-home position-relative'>
        <div className="top-wraper">
          <Container>

            <Row>
              <Col md={12}>
                <Navbar className="navbar navbar-default z-index-1000">
                  <Container fluid>
                    <Navbar.Collapse id="navbarScroll" className='headerNavHand'>
                      <Nav className="me-auto my-2 my-lg-0 text-white">
                        <NavLink to="/" className='text-white p-2'>Home</NavLink>
                        <NavLink to="/menu/1" className='text-white p-2'>menu</NavLink>
                      </Nav>
                      <NavLink href="/" className='navbar-brand'>
                        <img src="../public/logo.png" alt="" />
                      </NavLink>
                    </Navbar.Collapse>
                  </Container>
                </Navbar>
              </Col>
            </Row>

            <Row className='col'>
              <div className="open mt-5">
                <span>7 days a week</span>
                <p>12 to 12</p>
              </div>
            </Row>

            <Row>
              <div className="top-pic-categorym text-center row">
                <Col xs={2}>
                  <NavLink to="single" target="_blank">
                    <img src="../public/svg/pizzas-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/salads-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/sushi-big.svg" alt="" />
                  </NavLink>
                </Col>
                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/burgers-big.svg" alt="" />
                  </NavLink>
                </Col>

                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/desserts-big.svg" alt="" />
                  </NavLink>
                </Col>

                <Col xs={2}>
                  <NavLink to="single">
                    <img src="./public/svg/drinks-big.svg" alt="" />
                  </NavLink>
                </Col>
              </div>
            </Row>

            <Row>
              <div className="top-wrap-text">
                <h1 className='title special-font fs-1'>YOUR FOOD ON THE SPOT</h1>
                <h3 className='onder-title special-font fs-3'>WITH JUST ONE CALL AT YOUR OFFICE</h3>
                <NavLink to="/shop" className='order'>Order</NavLink>
              </div>
            </Row>

            <Row>
              <Col md={4}>
                <div className="service-bx">
                  <Row>
                    <Col md={4}>
                      <img src="./public/svg/feature-1.svg" alt="" />
                    </Col>
                    <Col md={8}>
                      <p className='title-servise-bx'>most delicious foods</p>
                      <p className='under-title-servise-bx'>Using the highest quality food</p>
                    </Col>
                  </Row>
                </div>
              </Col>
              <Col md={4}>
                <div className="service-bx">
                  <Row>
                    <Col md={4}>
                      <img src="./public/svg/feature-2.svg" alt="" />
                    </Col>
                    <Col md={8}>
                      <p className='title-servise-bx'>The best chefs</p>
                      <p className='under-title-servise-bx'>The best kitchen utensils</p>
                    </Col>
                  </Row>
                </div>
              </Col>

              <Col md={4}>
                <div className="service-bx">
                  <Row>
                    <Col md={4}>
                      <img src="./public/svg/feature-3.svg" alt="" />
                    </Col>
                    <Col md={8}>
                      <p className='title-servise-bx'>The fastest courier</p>
                      <p className='under-title-servise-bx'>The safest courier </p>
                    </Col>
                  </Row>
                </div>
              </Col>
            </Row>
          </Container>
        </div >
      </header >
      <div className="border-pattern mb-5"></div>
      <section className="mb-5">
        <Container>
          <div className="index-intro">
            <Row>
              <Col md={6}>
                <div className="right-bx">
                  <h4 className='mb-2'>Online food ordering with salsal</h4>
                  <h6 className='mt-2'>We are with you</h6>
                  <p className='mb-3'>LLorem Epsom is a mock text with an incomprehensible simplicity produced by the printing industry and used by graphic designers. Printers and texts, but newspapers and magazines in columns and rows as necessary and for the current conditions of the required technology and diverse applications with the aim of improving practical tools. Many books in the sixty-three percent of the past .</p>
                  <p className='mb-3'>Softly created a leading culture in the Persian language. In this case, there is hope. With software, he created more knowledge for computer designers, especially creative designers and leading culture in Persian language. In this case, there is hope.</p>
                  <p className='mb-3'>LSoftly created a leading culture in the Persian language. In this case, there is hope. With software, he created more knowledge for computer designers, especially creative designers and leading culture in Persian language. In this case, there is hope.</p>
                  <NavLink to="/menu/1" className="btn_se_light hi hover-color-dark">view menu</NavLink>
                </div>
              </Col>
              <Col md={6}>
                <div className="left-bx text-center">
                  <div className="row">
                    <Col md={6} className="col-xs-6 no-padding mb-md-0">
                      <img src="./public/top/snack-4.jpg" alt="" className="img-thumbnail" />
                    </Col>
                    <Col md={6} className="col-xs-6 no-padding mb-md-0">
                      <img src="./public/top/salad-3-01.jpg" alt="" className="img-rounded" />
                    </Col>
                    <Col md={6} className="col-xs-6 no-padding">
                      <img src="./public/top/salad-2.png" alt="" className="img-rounded" />
                    </Col>
                    <Col md={6} className="col-xs-6 no-padding">
                      <img src="./public/top/Fruit-Yogurt-2.jpg" alt="" className="img-thumbnail" />
                    </Col>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Container>
      </section>
      <section className="mam">
        <Container>
          <div className="title-head">
            <span>special products</span>
          </div>
          <div className="index-tabs">

            {/* <!-- Nav tabs --> */}
            <ul className="nav nav-tabs mb-5">
              <CategoryPagintion allCategoryUseing={allCategoryUseing} funcCategory={funcCategory} />
            </ul>

            {/* <!-- Tab panes --> */}
            <div className="tabs">
              <Row className='px-3 justify-content-center'>
                <CategoryPaginationProducts productsUseing={productsUseing} />
              </Row>
            </div>

          </div>
        </Container>
      </section>
      <div className="border-pattern index-rip"></div>
      <section className="top-wraperer">
        <div className="top-wraper">
          <div className="container">
            <div className="row">
              <div className="col-md-6">
                <div className="right-bx">
                  <h4 className='mt-4'>Chef's suggestion</h4>
                  <h6>Affordable and delicious</h6>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste iure iusto odio voluptatibus dolores velit adipisci repudiandae molestiae beatae hic inventore, natus ex qui fuga culpa rerum doloremque. Earum, voluptates!</p>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste iure iusto odio voluptatibus dolores velit adipisci repudiandae molestiae beatae hic inventore, natus ex qui fuga culpa rerum doloremque. Earum, voluptates!</p>
                  <div className="display-flex">
                    <NavLink to="/menu/1" className="btn_se_light hi">view menu</NavLink>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="big-image">
                  <figure>
                    <img src="./public/img-deal-of-the-week.png" alt="" />
                  </figure>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="class">
          <div className="border-pattern index-rip"></div>
        </div>
      </section>
      <section className="circle">
        <div className="top-wrap">
          <Container>
            <div className="title-head"><span>Family table</span></div>
            <div className="family-name">
              <Row>
                <Col md={4}>
                  <ul>
                    <li>
                      <Row>
                        <Col md={9}>
                          <span className='fs-5'>Family foods</span>
                          <p className='fs-6'>Lorem ipsum dolor sit.?</p>
                        </Col>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-1.svg" alt="" />
                          </div>
                        </Col>
                      </Row>
                    </li>
                    <li>

                      <Row>
                        <Col md={9}>
                          <span className='fs-5'>Baby foods</span>
                          <p className='fs-6'>Lorem ipsum dolor sit.</p>
                        </Col>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-2.svg" alt="" />
                          </div>
                        </Col>
                      </Row>
                    </li>
                    <li>


                      <Row>
                        <Col md={9}>
                          <span className='fs-5'>piece by piece</span>
                          <p className='fs-6'>Lorem ipsum dolor sit.</p>
                        </Col>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-3.svg" alt="" />
                          </div>
                        </Col>
                      </Row>


                    </li>
                  </ul>
                </Col>
                <Col md={4} className='text-center'>
                  <figure>
                    <img src="./public/top/salad-3-01.jpg" alt="" className="img-circle" />
                  </figure>
                </Col>
                <Col md={4}>
                  <ul>
                    <li>
                      <Row>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-4.svg" alt="" />
                          </div>
                        </Col>
                        <Col md={9}>
                          <span className='fs-5'>natural</span>
                          <p className='fs-6'>Lorem, ipsum dolor.</p>
                        </Col>
                      </Row>
                    </li>
                    <li>

                      <Row>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-1.svg" alt="" />
                          </div>
                        </Col>
                        <Col md={9}>
                          <span className='fs-5'>life by live</span>
                          <p className='fs-6'>Lorem, ipsum dolor.</p>
                        </Col>
                      </Row>



                    </li>
                    <li>



                      <Row>
                        <Col md={3}>
                          <div className="display-flex">
                            <img src="./public/svg/video-3.svg" alt="" />
                          </div>
                        </Col>
                        <Col md={9}>
                          <span className='fs-5'>baby foods</span>
                          <p className='fs-6'>Lorem, ipsum dolor.</p>
                        </Col>
                      </Row>

                    </li>
                  </ul>
                </Col>
              </Row>
            </div>
          </Container>
        </div >
      </section >
      <section className="email">
        <div className="class-index-rip">
          <div className="border-pattern mama index-rip"></div>
        </div>
        <div className="top-wraper">
          <Container>
            <Row className='text-center'>
              <div className="title-head mt-4">
                <span>subscribe to newsletter</span>
              </div>
              <Col className='col-md-offset-3'>
                <form action="">
                  <input type="email" placeholder="subscribe to newsletter (email please)" className='p-3 rounded border-0' />
                  <button className='border-0 rounded'><AlternateEmailIcon className='text-light' /></button>
                </form>
              </Col>
            </Row>
          </Container>
        </div>
        <div className="class-index-rip">
          <div className="border-pattern index-rip"></div>
        </div>
      </section>
      <section className="mb-5">

        <Container>
          <div className="title-head">
            <span>News and articles</span>
          </div>
          <div className="index-blog">
            <Row>
              <Posting Posts={Posts} />
            </Row>
          </div>
        </Container>

      </section>
      <section className="mt-40p">
        <Container fluid>
          <Row>
            <div className="title-head">
              <span>Breakfast</span>
            </div>
            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/011.jpg" alt="" />
              </figure>
            </Col>

            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/25-1.jpg" alt="" />
              </figure>
            </Col>
            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/02-2.jpg" alt="" />
              </figure>
            </Col>
            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/16-3.jpg" alt="" />
              </figure>
            </Col>
            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/breakfast-1.jpg" alt="" />
              </figure>
            </Col>
            <Col xs={2} className='nopadding'>
              <figure>
                <img src="./public/top/Juice-snack-2-02-600x600-1.png" alt="" />
              </figure>
            </Col>

          </Row>
        </Container>
      </section>
    </>
  )
}

