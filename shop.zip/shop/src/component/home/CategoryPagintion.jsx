import React, { useState } from 'react'

export default function CategoryPagintion({ allCategoryUseing, funcCategory }) {

  const [pageItemActive, setPageItemActive] = useState('offer')

  return (
    allCategoryUseing.map(category => (
      <li key={category} onClick={() => {
        funcCategory(category)
        setPageItemActive(category)
      }} className={`paginationProductsAll ${pageItemActive === category ? 'active' : ''}`}><span>{category}</span></li>
    ))
  )
}
