import { Container , Row , Col  } from "react-bootstrap"
import { NavLink } from "react-router-dom"

import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import YouTubeIcon from '@mui/icons-material/YouTube';




export default function footer() {
  return (
    <footer className="mb-5">
      <div className="container">
        <div className="row">
        </div>
      </div>
      <Container>
        <Row>
          <Col>
            <div className="footer-menu">
              <ul>
                <li><NavLink to="/">HOME</NavLink></li>
                <li><NavLink to="/shop">shop</NavLink></li>
                <li><NavLink to="/blog">blog</NavLink></li>
                <li><NavLink to="/single">single</NavLink></li>
              </ul>
            </div>
            <div className="footer-desc text-center">
              <h4>Delightful Responsive Design with salsal </h4>
              <p>Be our special member with an order</p>
            </div>
            <div className="footer-social">
              <ul className="ul-2">
                <li ><NavLink to="/"><InstagramIcon className="footer-icon" /></NavLink></li>
                <li ><NavLink to="/"><YouTubeIcon className="footer-icon"/></NavLink></li>
                <li ><NavLink to="/"><TwitterIcon className="footer-icon"/></NavLink></li>
                <li ><NavLink to="/"><LinkedInIcon className="footer-icon"/></NavLink></li>
              </ul>
            </div>
          </Col>
        </Row>
      </Container>
    </footer>
  )
}
